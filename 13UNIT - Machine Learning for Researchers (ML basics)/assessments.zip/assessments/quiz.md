# Quiz — 13UNIT

## Questions

1. Explain why a test set must not be used during hyperparameter tuning.

2. Give an example of target leakage and describe a practical mitigation.

3. When does accuracy become misleading, and which metrics may be preferable?

4. Interpret a learning curve where training error is low and validation error is high.

5. Describe the purpose of nested cross-validation.

6. Define the difference between generative and discriminative models in terms of what is modelled.

7. Explain why standardisation is often necessary for k-means.

8. State a limitation of silhouette score.

9. What is the role of regularisation in linear models?

10. Why should random seeds be recorded in empirical ML studies?



## Model answers

Answers should be expressed as short arguments rather than slogans. Where relevant, refer to the evaluation protocol and the data-generating assumptions.




From a methodological perspective, the central difficulty is not writing code but specifying the inferential claim, the assumptions under which it is defensible and the diagnostics that reveal when those assumptions fail.

Accordingly, each experiment should be accompanied by a record of data provenance, preprocessing choices and metric definitions, because these decisions often dominate model selection effects when datasets are modest in size.

In applied work, it is prudent to treat performance estimates as random variables conditioned on a sampling design; resampling methods and confidence intervals are therefore discussed alongside point estimates.

From a methodological perspective, the central difficulty is not writing code but specifying the inferential claim, the assumptions under which it is defensible and the diagnostics that reveal when those assumptions fail.

Accordingly, each experiment should be accompanied by a record of data provenance, preprocessing choices and metric definitions, because these decisions often dominate model selection effects when datasets are modest in size.

In applied work, it is prudent to treat performance estimates as random variables conditioned on a sampling design; resampling methods and confidence intervals are therefore discussed alongside point estimates.

From a methodological perspective, the central difficulty is not writing code but specifying the inferential claim, the assumptions under which it is defensible and the diagnostics that reveal when those assumptions fail.

Accordingly, each experiment should be accompanied by a record of data provenance, preprocessing choices and metric definitions, because these decisions often dominate model selection effects when datasets are modest in size.

In applied work, it is prudent to treat performance estimates as random variables conditioned on a sampling design; resampling methods and confidence intervals are therefore discussed alongside point estimates.

From a methodological perspective, the central difficulty is not writing code but specifying the inferential claim, the assumptions under which it is defensible and the diagnostics that reveal when those assumptions fail.

Accordingly, each experiment should be accompanied by a record of data provenance, preprocessing choices and metric definitions, because these decisions often dominate model selection effects when datasets are modest in size.

In applied work, it is prudent to treat performance estimates as random variables conditioned on a sampling design; resampling methods and confidence intervals are therefore discussed alongside point estimates.

From a methodological perspective, the central difficulty is not writing code but specifying the inferential claim, the assumptions under which it is defensible and the diagnostics that reveal when those assumptions fail.

Accordingly, each experiment should be accompanied by a record of data provenance, preprocessing choices and metric definitions, because these decisions often dominate model selection effects when datasets are modest in size.

In applied work, it is prudent to treat performance estimates as random variables conditioned on a sampling design; resampling methods and confidence intervals are therefore discussed alongside point estimates.

From a methodological perspective, the central difficulty is not writing code but specifying the inferential claim, the assumptions under which it is defensible and the diagnostics that reveal when those assumptions fail.

Accordingly, each experiment should be accompanied by a record of data provenance, preprocessing choices and metric definitions, because these decisions often dominate model selection effects when datasets are modest in size.

In applied work, it is prudent to treat performance estimates as random variables conditioned on a sampling design; resampling methods and confidence intervals are therefore discussed alongside point estimates.