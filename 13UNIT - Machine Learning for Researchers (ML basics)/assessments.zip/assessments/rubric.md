# Rubric — 13UNIT

## Criteria

Reproducibility (25%): The code executes from a clean environment using the documented commands and it reproduces the reported figures and metrics.

Methodological correctness (35%): The evaluation protocol avoids leakage, uses an appropriate split design and reports metrics suitable for the task.

Interpretation (25%): The discussion connects model behaviour to bias–variance, data limitations and plausible threats to validity.

Presentation (15%): The report is concise, technically accurate and uses well-labelled figures and tables.




From a methodological perspective, the central difficulty is not writing code but specifying the inferential claim, the assumptions under which it is defensible and the diagnostics that reveal when those assumptions fail.

Accordingly, each experiment should be accompanied by a record of data provenance, preprocessing choices and metric definitions, because these decisions often dominate model selection effects when datasets are modest in size.

In applied work, it is prudent to treat performance estimates as random variables conditioned on a sampling design; resampling methods and confidence intervals are therefore discussed alongside point estimates.

From a methodological perspective, the central difficulty is not writing code but specifying the inferential claim, the assumptions under which it is defensible and the diagnostics that reveal when those assumptions fail.

Accordingly, each experiment should be accompanied by a record of data provenance, preprocessing choices and metric definitions, because these decisions often dominate model selection effects when datasets are modest in size.

In applied work, it is prudent to treat performance estimates as random variables conditioned on a sampling design; resampling methods and confidence intervals are therefore discussed alongside point estimates.

From a methodological perspective, the central difficulty is not writing code but specifying the inferential claim, the assumptions under which it is defensible and the diagnostics that reveal when those assumptions fail.

Accordingly, each experiment should be accompanied by a record of data provenance, preprocessing choices and metric definitions, because these decisions often dominate model selection effects when datasets are modest in size.

In applied work, it is prudent to treat performance estimates as random variables conditioned on a sampling design; resampling methods and confidence intervals are therefore discussed alongside point estimates.

From a methodological perspective, the central difficulty is not writing code but specifying the inferential claim, the assumptions under which it is defensible and the diagnostics that reveal when those assumptions fail.

Accordingly, each experiment should be accompanied by a record of data provenance, preprocessing choices and metric definitions, because these decisions often dominate model selection effects when datasets are modest in size.

In applied work, it is prudent to treat performance estimates as random variables conditioned on a sampling design; resampling methods and confidence intervals are therefore discussed alongside point estimates.

From a methodological perspective, the central difficulty is not writing code but specifying the inferential claim, the assumptions under which it is defensible and the diagnostics that reveal when those assumptions fail.

Accordingly, each experiment should be accompanied by a record of data provenance, preprocessing choices and metric definitions, because these decisions often dominate model selection effects when datasets are modest in size.

In applied work, it is prudent to treat performance estimates as random variables conditioned on a sampling design; resampling methods and confidence intervals are therefore discussed alongside point estimates.